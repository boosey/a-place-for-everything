importScripts('bower_components/platinum-sw/service-worker.js');
